#!/usr/bin/env python3
"""
GCP Backend Service Capacity Scaler
====================================

This script manages the capacity scaling for GCP Load Balancer backend services.
It can:
- Get current capacity scaler values
- Update capacity scaler for specific backends
- Validate capacity scaler values
- List all backends with their current capacity settings

Usage:
    python capacity_scaler.py --help
"""

import argparse
import json
import sys
import logging
import os
from typing import Dict, List, Optional, Any
from google.cloud import compute_v1
from google.auth import default
import google.oauth2.credentials
import yaml

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('capacity_scaler.log')
    ]
)
logger = logging.getLogger(__name__)


class CapacityScaler:
    """Manages GCP Backend Service Capacity Scaling operations."""
    
    def __init__(self, project_id: str, region: str = None):
        """
        Initialize the CapacityScaler.
        
        Args:
            project_id: GCP Project ID
            region: GCP Region (optional, for regional backend services)
        """
        self.project_id = project_id
        self.region = region
        
        # Initialize GCP clients
        try:
            # Check if we have an access token from environment
            access_token = os.environ.get('CLOUDSDK_AUTH_ACCESS_TOKEN')
            if access_token:
                logger.info("Using access token authentication")
                # Create OAuth2 credentials with the access token
                credentials = google.oauth2.credentials.Credentials(token=access_token)
            else:
                # Check if GOOGLE_APPLICATION_CREDENTIALS is set but empty
                creds_path = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
                if creds_path == "":
                    logger.info("GOOGLE_APPLICATION_CREDENTIALS is empty, unsetting it")
                    if 'GOOGLE_APPLICATION_CREDENTIALS' in os.environ:
                        del os.environ['GOOGLE_APPLICATION_CREDENTIALS']
                
                logger.info("Using default credentials (ADC or service account)")
                credentials, _ = default()
            
            self.backend_service_client = compute_v1.BackendServicesClient(credentials=credentials)
            self.regional_backend_service_client = compute_v1.RegionBackendServicesClient(credentials=credentials)
            logger.info(f"Initialized GCP clients for project: {project_id}")
        except Exception as e:
            logger.error(f"Failed to initialize GCP clients: {e}")
            logger.error("Authentication troubleshooting:")
            logger.error("1. For local development: use 'gcloud auth application-default login'")
            logger.error("2. For GitLab CI: ensure GCP_ACCESS_TOKEN is set with 'gcloud auth print-access-token'")
            logger.error("3. For service accounts: set GOOGLE_APPLICATION_CREDENTIALS to key file path")
            raise
    
    def validate_capacity_scaler(self, capacity_scaler: float) -> bool:
        """
        Validate capacity scaler value.
        
        Args:
            capacity_scaler: The capacity scaler value (0.0 to 1.0)
            
        Returns:
            bool: True if valid, False otherwise
        """
        if not isinstance(capacity_scaler, (int, float)):
            logger.error(f"Capacity scaler must be a number, got {type(capacity_scaler)}")
            return False
        
        if not (0.0 <= capacity_scaler <= 1.0):
            logger.error(f"Capacity scaler must be between 0.0 and 1.0, got {capacity_scaler}")
            return False
        
        return True
    
    def get_backend_service(self, backend_service_name: str) -> Optional[Any]:
        """
        Get backend service details.
        
        Args:
            backend_service_name: Name of the backend service
            
        Returns:
            Backend service object or None if not found
        """
        try:
            if self.region:
                # Regional backend service
                request = compute_v1.GetRegionBackendServiceRequest(
                    project=self.project_id,
                    region=self.region,
                    backend_service=backend_service_name
                )
                return self.regional_backend_service_client.get(request=request)
            else:
                # Global backend service
                request = compute_v1.GetBackendServiceRequest(
                    project=self.project_id,
                    backend_service=backend_service_name
                )
                return self.backend_service_client.get(request=request)
        except Exception as e:
            logger.error(f"Failed to get backend service {backend_service_name}: {e}")
            return None
    
    def list_backends_with_capacity(self, backend_service_name: str) -> Dict[str, Any]:
        """
        List all backends with their current capacity scaler values.
        
        Args:
            backend_service_name: Name of the backend service
            
        Returns:
            Dictionary with backend information
        """
        backend_service = self.get_backend_service(backend_service_name)
        if not backend_service:
            return {}
        
        backends_info = {}
        for backend in backend_service.backends:
            backend_info = {
                'group': backend.group,
                'capacity_scaler': backend.capacity_scaler,
                'max_utilization': getattr(backend, 'max_utilization', None),
                'balancing_mode': backend.balancing_mode
            }
            backends_info[backend.group.split('/')[-1]] = backend_info
        
        return backends_info
    
    def update_capacity_scaler(self, backend_service_name: str, backend_group: str, 
                             new_capacity_scaler: float, dry_run: bool = False) -> bool:
        """
        Update capacity scaler for a specific backend.
        
        Args:
            backend_service_name: Name of the backend service
            backend_group: Backend group identifier
            new_capacity_scaler: New capacity scaler value
            dry_run: If True, only validate and show what would be changed
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not self.validate_capacity_scaler(new_capacity_scaler):
            return False
        
        backend_service = self.get_backend_service(backend_service_name)
        if not backend_service:
            return False
        
        # Find the backend to update
        backend_found = False
        for backend in backend_service.backends:
            if backend_group in backend.group:
                current_capacity = backend.capacity_scaler
                
                if dry_run:
                    logger.info(f"DRY RUN: Would update {backend_group}")
                    logger.info(f"  Current capacity scaler: {current_capacity}")
                    logger.info(f"  New capacity scaler: {new_capacity_scaler}")
                    return True
                
                # Update the capacity scaler
                backend.capacity_scaler = new_capacity_scaler
                backend_found = True
                
                logger.info(f"Updated {backend_group}: {current_capacity} -> {new_capacity_scaler}")
                break
        
        if not backend_found:
            logger.error(f"Backend group {backend_group} not found in {backend_service_name}")
            return False
        
        if dry_run:
            return True
        
        # Apply the update
        try:
            if self.region:
                request = compute_v1.PatchRegionBackendServiceRequest(
                    project=self.project_id,
                    region=self.region,
                    backend_service=backend_service_name,
                    backend_service_resource=backend_service
                )
                operation = self.regional_backend_service_client.patch(request=request)
            else:
                request = compute_v1.PatchBackendServiceRequest(
                    project=self.project_id,
                    backend_service=backend_service_name,
                    backend_service_resource=backend_service
                )
                operation = self.backend_service_client.patch(request=request)
            
            logger.info(f"Update operation started: {operation.name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to update backend service: {e}")
            return False
    
    def batch_update_capacity_scalers(self, backend_service_name: str, 
                                    updates: Dict[str, float], dry_run: bool = False) -> bool:
        """
        Update multiple backends' capacity scalers in a single operation.
        
        Args:
            backend_service_name: Name of the backend service
            updates: Dictionary mapping backend group names to new capacity scaler values
            dry_run: If True, only validate and show what would be changed
            
        Returns:
            bool: True if all updates successful, False otherwise
        """
        logger.info(f"Starting batch update for {len(updates)} backends (dry_run={dry_run})")
        logger.info(f"Updates to apply: {updates}")
        
        # Validate all capacity scaler values first
        for backend_group, capacity_scaler in updates.items():
            if not self.validate_capacity_scaler(capacity_scaler):
                logger.error(f"Invalid capacity scaler for {backend_group}: {capacity_scaler}")
                return False
        
        backend_service = self.get_backend_service(backend_service_name)
        if not backend_service:
            return False
        
        logger.info(f"Found backend service with {len(backend_service.backends)} backends")
        updates_applied = 0
        
        # Apply updates
        for backend in backend_service.backends:
            backend_name = backend.group.split('/')[-1]  # Get just the name part
            logger.info(f"Checking backend: {backend_name} (full path: {backend.group})")
            
            for backend_group, new_capacity_scaler in updates.items():
                if backend_group == backend_name or backend_group in backend.group:
                    current_capacity = backend.capacity_scaler
                    
                    if dry_run:
                        logger.info(f"DRY RUN: Would update {backend_group}")
                        logger.info(f"  Current capacity scaler: {current_capacity}")
                        logger.info(f"  New capacity scaler: {new_capacity_scaler}")
                    else:
                        backend.capacity_scaler = new_capacity_scaler
                        logger.info(f"Updated {backend_group}: {current_capacity} -> {new_capacity_scaler}")
                    
                    updates_applied += 1
                    break
        
        if dry_run:
            logger.info(f"DRY RUN: Would apply {updates_applied} updates")
            return True
        
        if updates_applied == 0:
            logger.warning("No backends were updated - check backend names match")
            logger.info("Available backends:")
            for backend in backend_service.backends:
                logger.info(f"  - {backend.group.split('/')[-1]} (full: {backend.group})")
            return False
        
        # Apply the batch update
        try:
            if self.region:
                request = compute_v1.PatchRegionBackendServiceRequest(
                    project=self.project_id,
                    region=self.region,
                    backend_service=backend_service_name,
                    backend_service_resource=backend_service
                )
                operation = self.regional_backend_service_client.patch(request=request)
            else:
                request = compute_v1.PatchBackendServiceRequest(
                    project=self.project_id,
                    backend_service=backend_service_name,
                    backend_service_resource=backend_service
                )
                operation = self.backend_service_client.patch(request=request)
            
            logger.info(f"Batch update operation started: {operation.name}")
            logger.info(f"Successfully applied {updates_applied} capacity scaler updates")
            return True
            
        except Exception as e:
            logger.error(f"Failed to apply batch update: {e}")
            return False


def load_config_from_file(config_file: str) -> Dict[str, Any]:
    """Load configuration from YAML or JSON file."""
    try:
        with open(config_file, 'r') as f:
            if config_file.endswith('.yaml') or config_file.endswith('.yml'):
                return yaml.safe_load(f)
            else:
                return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load config file {config_file}: {e}")
        return {}


def main():
    """Main function to handle command line interface."""
    parser = argparse.ArgumentParser(
        description="GCP Backend Service Capacity Scaler Management Tool"
    )
    
    # Required arguments
    parser.add_argument('--project-id', required=True, help='GCP Project ID')
    parser.add_argument('--backend-service', required=True, help='Backend service name')
    
    # Optional arguments
    parser.add_argument('--region', help='GCP Region for regional backend services')
    parser.add_argument('--dry-run', action='store_true', help='Show what would be changed without applying')
    
    # Action subcommands
    subparsers = parser.add_subparsers(dest='action', help='Available actions')
    
    # List action
    list_parser = subparsers.add_parser('list', help='List all backends with capacity scalers')
    
    # Update single backend
    update_parser = subparsers.add_parser('update', help='Update capacity scaler for a single backend')
    update_parser.add_argument('--backend-group', required=True, help='Backend group name')
    update_parser.add_argument('--capacity-scaler', type=float, required=True, 
                              help='New capacity scaler value (0.0-1.0)')
    
    # Batch update from config
    batch_parser = subparsers.add_parser('batch', help='Batch update from configuration file')
    batch_parser.add_argument('--config-file', required=True, help='YAML/JSON config file path')
    
    # Batch update from CLI
    cli_batch_parser = subparsers.add_parser('batch-cli', help='Batch update from command line')
    cli_batch_parser.add_argument('--updates', required=True, 
                                 help='JSON string with backend:capacity_scaler mappings')
    
    args = parser.parse_args()
    
    if not args.action:
        parser.print_help()
        return 1
    
    # Initialize the capacity scaler
    try:
        scaler = CapacityScaler(args.project_id, args.region)
    except Exception as e:
        logger.error(f"Failed to initialize CapacityScaler: {e}")
        return 1
    
    # Execute the requested action
    if args.action == 'list':
        backends = scaler.list_backends_with_capacity(args.backend_service)
        if backends:
            print(json.dumps(backends, indent=2))
        else:
            logger.error("No backends found or failed to retrieve backend information")
            return 1
    
    elif args.action == 'update':
        success = scaler.update_capacity_scaler(
            args.backend_service, 
            args.backend_group, 
            args.capacity_scaler,
            args.dry_run
        )
        return 0 if success else 1
    
    elif args.action == 'batch':
        config = load_config_from_file(args.config_file)
        if not config:
            return 1
        
        updates = config.get('capacity_scalers', {})
        if not updates:
            logger.error("No 'capacity_scalers' section found in config file")
            return 1
        
        success = scaler.batch_update_capacity_scalers(
            args.backend_service, 
            updates, 
            args.dry_run
        )
        return 0 if success else 1
    
    elif args.action == 'batch-cli':
        try:
            updates = json.loads(args.updates)
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in --updates: {e}")
            return 1
        
        success = scaler.batch_update_capacity_scalers(
            args.backend_service, 
            updates, 
            args.dry_run
        )
        return 0 if success else 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
