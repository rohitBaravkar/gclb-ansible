# GitLab Pipeline Execution Guide

This guide covers how to run the GCP Backend Service Capacity Scaler GitLab CI/CD pipeline.

## 🎯 Overview

The GitLab pipeline provides a safe, controlled way to scale GCP Load Balancer backend services with:
- **Manual triggers** - All operations require explicit approval
- **Dry-run first** - Always preview changes before applying
- **Operation types** - Different scaling scenarios
- **Access token authentication** - Secure, time-limited access

## 🛠️ Prerequisites

### 1. Local Environment Setup
- **Google Cloud SDK (gcloud)** installed and configured
- **Access to the target GCP project**
- **GitLab project** with this pipeline code

### 2. Required GCP Permissions
Your GCP user account needs these IAM roles:
- `Compute Engine Admin` (or custom role with specific permissions)
- Specific permissions required:
  - `compute.backendServices.get`
  - `compute.backendServices.update`
  - `compute.backendServices.list`

## 🔑 Getting GCP Access Token

### Step 1: Authenticate with gcloud
```bash
# Login to gcloud (opens browser for authentication)
gcloud auth login

# Set your project
gcloud config set project YOUR_PROJECT_ID

# Verify authentication
gcloud auth list
```

### Step 2: Generate Access Token
```bash
# Generate a fresh access token
gcloud auth print-access-token
```

**Example output:**
```
ya29.a0AfH6SMCxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

⚠️ **Important Notes:**
- Access tokens expire after **1 hour**
- Generate a fresh token for each pipeline run
- Keep tokens secure - don't share or log them

### Step 3: Copy the Token
- Copy the entire token string
- You'll paste this into the GitLab pipeline variables

## 🚀 Running the Pipeline

### Option 1: GitLab Web Interface

#### 1. Navigate to Pipeline
1. Go to your GitLab project
2. Navigate to **CI/CD > Pipelines**
3. Click **Run Pipeline**

#### 2. Set Required Variables
Fill in these variables when prompted:

| Variable | Value | Example |
|----------|--------|---------|
| `GCP_PROJECT_ID` | Your GCP project ID | `my-production-project` |
| `BACKEND_SERVICE` | Target backend service name | `my-app-backend-service` |
| `GCP_ACCESS_TOKEN` | Token from gcloud command | `ya29.a0AfH6SMC...` |
| `OPERATION_TYPE` | Select from dropdown | `capacity-change` |
| `CAPACITY_UPDATES` | JSON with desired changes | `{"neg-a": 0.8, "neg-b": 0.6}` |

#### 3. Execute Pipeline Stages

**Stage 1: Validation (Optional)**
```bash
# Manually trigger: validate-operation
# This checks all your variables are set correctly
```

**Stage 2: Verify Changes (Required)**
```bash
# Manually trigger: verify-capacity-changes
# This shows you exactly what will change (dry-run)
```

**Stage 3: Apply Changes (Final)**
```bash
# Manually trigger: apply-capacity-changes
# This actually applies the changes
```

### Option 2: GitLab API

You can also trigger pipelines via GitLab API:

```bash
# Set your variables
PROJECT_ID="your-gitlab-project-id"
GITLAB_TOKEN="your-gitlab-token"
GCP_TOKEN=$(gcloud auth print-access-token)

# Trigger pipeline with variables
curl -X POST \
  -H "PRIVATE-TOKEN: $GITLAB_TOKEN" \
  -F "ref=main" \
  -F "variables[GCP_PROJECT_ID]=my-production-project" \
  -F "variables[BACKEND_SERVICE]=my-app-backend-service" \
  -F "variables[GCP_ACCESS_TOKEN]=$GCP_TOKEN" \
  -F "variables[OPERATION_TYPE]=capacity-change" \
  -F "variables[CAPACITY_UPDATES]={\"neg-a\": 0.8, \"neg-b\": 0.6}" \
  "https://gitlab.com/api/v4/projects/$PROJECT_ID/pipeline"
```

## 📋 Pipeline Operations

### 1. Capacity Change Operation

**Purpose:** Update specific backend capacities

**Required Variables:**
- `OPERATION_TYPE`: `capacity-change`
- `CAPACITY_UPDATES`: JSON with backend names and desired capacity values

**Example Scenarios:**

#### Regular Scaling
```json
{
  "neg-us-west": 0.7,
  "neg-us-east": 0.8,
  "neg-europe": 0.6
}
```

#### Maintenance Mode
```json
{
  "neg-us-west": 0.2,
  "neg-us-east": 0.2,
  "neg-europe": 0.2
}
```

#### Load Testing
```json
{
  "neg-us-west": 1.0,
  "neg-us-east": 1.0,
  "neg-europe": 1.0
}
```

### 2. Emergency Operations (Coming Soon)

Future pipeline versions will include:
- `emergency-scale-down`: Scale all backends to 0.1
- `peak-load-scale`: Scale all backends to 1.0
- `list-backends`: Show current backend status
- `validate-connection`: Test GCP connection

## 🔄 Complete Workflow Example

Here's a complete example of scaling backend services:

### 1. Prepare Access Token
```bash
# Get fresh token
gcloud auth print-access-token
# Copy output: ya29.a0AfH6SMC...
```

### 2. Set Pipeline Variables
```yaml
GCP_PROJECT_ID: "my-production-project"
BACKEND_SERVICE: "my-app-backend-service"
GCP_ACCESS_TOKEN: "ya29.a0AfH6SMC..."
OPERATION_TYPE: "capacity-change"
CAPACITY_UPDATES: '{"neg-west": 0.7, "neg-east": 0.8}'
```

### 3. Execute Pipeline
1. **Run Pipeline** with variables above
2. **Trigger** `verify-capacity-changes` job
3. **Review** the dry-run output
4. **Trigger** `apply-capacity-changes` job if satisfied

### 4. Verify Results
The pipeline will show:
- Current backend state (before)
- Proposed changes (dry-run)
- Updated backend state (after)

## 🐛 Troubleshooting

### Common Issues and Solutions

#### Token Expired
```
❌ Invalid or expired GCP access token
```
**Solution:** Generate a fresh token
```bash
gcloud auth print-access-token
```

#### Authentication Failed
```
Error: Failed to initialize GCP clients
```
**Solutions:**
1. Verify token is fresh and complete
2. Check your gcloud authentication:
   ```bash
   gcloud auth list
   gcloud auth login  # if needed
   ```

#### Permission Denied
```
Error: Permission denied on backend service
```
**Solutions:**
1. Verify GCP project ID is correct
2. Check your IAM permissions
3. Ensure backend service name is exact

#### Backend Service Not Found
```
Error: Backend service not found
```
**Solutions:**
1. List all backend services:
   ```bash
   gcloud compute backend-services list --project=YOUR_PROJECT_ID
   ```
2. Verify the exact service name (case-sensitive)

#### Invalid JSON in CAPACITY_UPDATES
```
Error: Invalid JSON format
```
**Solution:** Validate your JSON:
```bash
# Test JSON validity
echo '{"neg-a": 0.5, "neg-b": 0.7}' | jq .
```

### Debug Mode

For additional debugging, the pipeline includes debug output:
- Environment variable values
- Authentication status
- Token validation
- Detailed operation logs

## 📊 Monitoring Pipeline Progress

### 1. GitLab Pipeline View
- Monitor job progress in real-time
- View detailed logs for each stage
- Check job artifacts and outputs

### 2. Key Log Messages to Watch

**Successful Authentication:**
```
✅ GCP access token validated
Using access token authentication
✅ Initialized GCP clients
```

**Successful Verification:**
```
📊 Current Backend State:
[backend status output]
🔧 Proposed Changes (DRY RUN):
[proposed changes output]
✅ Verification complete
```

**Successful Application:**
```
🔧 Applying Capacity Changes:
[change application output]
📊 Updated Backend State:
[final status output]
✅ Capacity scaling completed successfully!
```

## 🔒 Security Best Practices

### 1. Token Security
- Never commit access tokens to code
- Use GitLab's variable masking features
- Generate fresh tokens for each run
- Rotate tokens regularly

### 2. Access Control
- Use least-privilege IAM roles
- Limit backend service access
- Monitor pipeline execution logs
- Set up alerts for scaling operations

### 3. Change Management
- Always run verify stage first
- Review dry-run output carefully
- Document capacity changes
- Have rollback procedures ready

## 📚 Related Documentation

- **[Local Development Guide](LOCAL_RUN.md)** - How to run scripts locally
- **[Main Project README](README.md)** - Project overview
- **[GitLab Variables Setup](GITLAB_VARIABLES.md)** - Variable configuration
- **[Pipeline Usage Details](PIPELINE_USAGE.md)** - Detailed usage instructions

## 🆘 Emergency Procedures

### Quick Access Token Generation
```bash
# One-liner to get token quickly
gcloud auth print-access-token | pbcopy  # macOS
gcloud auth print-access-token | clip    # Windows
```

### Emergency Scale Down (Manual)
If pipeline fails and you need immediate scale down:
```bash
# Generate token
TOKEN=$(gcloud auth print-access-token)

# Use local script for emergency
python3 capacity_scaler.py \
  --project-id YOUR_PROJECT_ID \
  --backend-service YOUR_BACKEND_SERVICE \
  emergency-scale-down
```

### Pipeline Retry
If a job fails:
1. Check error logs
2. Fix the issue (usually fresh token needed)
3. Retry the failed job
4. Or restart entire pipeline with new variables

## 💡 Tips for Success

1. **Token Management**: Set a reminder to refresh tokens every 45 minutes
2. **Variable Templates**: Save common variable sets for reuse
3. **Staging First**: Test on staging environments before production
4. **Documentation**: Keep a log of capacity changes and reasons
5. **Monitoring**: Watch application metrics during scaling operations
6. **Backup Plans**: Always have rollback capacity values ready
