# GCP Backend Service Capacity Scaler

A simple, generic capacity scaling solution for GCP Load Balancer backend services.

## 📁 Files

### Core Files
- **`.gitlab-ci.yml`** - GitLab CI/CD pipeline for capacity scaling
- **`capacity_scaler.py`** - Main Python script for capacity operations
- **`requirements.txt`** - Python dependencies

### Configuration & Examples
- **`config.yml`** - Example configuration templates (if present)

### Documentation
- **`PIPELINE_EXECUTION.md`** - Complete pipeline execution guide ✅
- **`QUICK_START.md`** - Quick reference for pipeline usage ✅
- **`LOCAL_RUN.md`** - Local development guide (create if needed)
- **`GITLAB_VARIABLES.md`** - GitLab variable setup guide (create if needed)
- **`PIPELINE_USAGE.md`** - Detailed pipeline usage (create if needed)

## 🚀 Quick Start

### Option 1: Use GitLab Pipeline (Recommended)
1. **Get GCP Access Token**: `gcloud auth print-access-token`
2. **Run Pipeline**: See [PIPELINE_EXECUTION.md](PIPELINE_EXECUTION.md) for complete instructions
3. **Quick Reference**: See [QUICK_START.md](QUICK_START.md) for fast setup

### Option 2: Local Development
1. **Install Dependencies**: `pip install -r requirements.txt`
2. **Set Authentication**: `gcloud auth application-default login`
3. **Get Help**: `python capacity_scaler.py --help`

---

## 📋 GitLab Pipeline Setup

### 1. Set GitLab Variables

In GitLab → Settings → CI/CD → Variables, add:

- **`GCP_PROJECT_ID`** - Your GCP project ID
- **`BACKEND_SERVICE`** - Your backend service name
- **`GCP_SERVICE_ACCOUNT_KEY`** - Service account JSON key (file)
- **`CAPACITY_UPDATES`** - JSON with desired changes

### 2. Example CAPACITY_UPDATES

```json
{"neg-a": 0.5, "neg-b": 0.7}
```

This sets:
- neg-a to 50% capacity
- neg-b to 70% capacity

### 3. Run Pipeline

1. Push to main branch
2. Trigger `verify-capacity-changes` (dry-run)
3. Review output
4. Trigger `apply-capacity-changes` (apply changes)

## 🎯 Key Features

✅ **Generic One-Time Use** - No environment concepts  
✅ **JSON Configuration** - Simple variable-based setup  
✅ **Dry-Run First** - Always preview before applying  
✅ **Emergency Operations** - Quick scale-down/scale-up  
✅ **Manual Control** - All operations require manual trigger  

## 📝 Pipeline Jobs

### Verify Stage
- **`verify-capacity-changes`** - Preview what will change (dry-run)
- **`list-backends`** - Show current backend state

### Apply Stage
- **`apply-capacity-changes`** - Apply the capacity changes
- **`emergency-scale-down`** - Set all backends to 0.1 capacity
- **`peak-load-scale`** - Set all backends to 1.0 capacity

## 💡 Common Use Cases

### Regular Capacity Adjustment
```json
{"neg-west": 0.6, "neg-east": 0.8, "neg-central": 0.5}
```

### Scale Down for Maintenance
```json
{"neg-west": 0.2, "neg-east": 0.2, "neg-central": 0.2}
```

### Load Testing Preparation
```json
{"neg-west": 1.0, "neg-east": 1.0, "neg-central": 1.0}
```

### Emergency Scale Down
Use the `emergency-scale-down` job - automatically sets all backends to 0.1

### Peak Load Scaling
Use the `peak-load-scale` job - automatically sets all backends to 1.0

## 🔧 Manual Script Usage

You can also run the Python script directly for local development or testing:

### Basic Setup
```bash
# Install dependencies
pip install -r requirements.txt

# Get script help
python capacity_scaler.py --help
```

### Authentication Options

**Option 1: Service Account Key**
```bash
# Linux/macOS
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account-key.json"

# Windows PowerShell
$env:GOOGLE_APPLICATION_CREDENTIALS = "C:\path\to\service-account-key.json"
```

**Option 2: gcloud Authentication**
```bash
# Use gcloud default credentials
gcloud auth application-default login
```

**Option 3: Access Token (like GitLab CI)**
```bash
# Linux/macOS
export CLOUDSDK_AUTH_ACCESS_TOKEN="$(gcloud auth print-access-token)"

# Windows PowerShell
$env:CLOUDSDK_AUTH_ACCESS_TOKEN = gcloud auth print-access-token
```

### Common Operations

```bash
# List current backends and their capacity
python capacity_scaler.py --project-id PROJECT_ID --backend-service SERVICE_NAME list

# Preview capacity changes (dry-run)
python capacity_scaler.py --project-id PROJECT_ID --backend-service SERVICE_NAME --dry-run batch-cli --updates '{"neg-a": 0.5}'

# Apply capacity changes
python capacity_scaler.py --project-id PROJECT_ID --backend-service SERVICE_NAME batch-cli --updates '{"neg-a": 0.5}'
```

> **Note**: Some advanced features like `emergency-scale-down` and `peak-load-scale` may require additional implementation. Check script help for available commands.

## 🔒 Security

- Use minimal GCP IAM permissions (`compute.backendServices.get`, `compute.backendServices.update`)
- Enable Protected and Masked flags on GitLab variables
- Rotate service account keys regularly

## 📚 Documentation

### Available Guides
- **[Pipeline Execution Guide](PIPELINE_EXECUTION.md)** - Complete guide for running GitLab CI/CD pipeline
- **[Quick Start Guide](QUICK_START.md)** - Fast reference for pipeline execution

### Additional Documentation
> Some documentation files may be created based on your specific setup needs:

- **Local Run Guide** - How to run and test scripts locally (create `LOCAL_RUN.md` if needed)
- **GitLab Variables Setup** - How to configure GitLab CI/CD variables (create `GITLAB_VARIABLES.md` if needed)  
- **Pipeline Usage Guide** - Detailed pipeline usage instructions (create `PIPELINE_USAGE.md` if needed)

### Quick Help
If you need immediate assistance:
1. **For pipeline execution**: See [PIPELINE_EXECUTION.md](PIPELINE_EXECUTION.md)
2. **For quick reference**: See [QUICK_START.md](QUICK_START.md)
3. **For local development**: Run `python capacity_scaler.py --help`

## 🆘 Troubleshooting

### Common Issues
1. **Authentication Failed** - Check your authentication method:
   - For GitLab CI: Verify `GCP_ACCESS_TOKEN` is fresh (expires in 1 hour)
   - For local: Check `GOOGLE_APPLICATION_CREDENTIALS` or run `gcloud auth application-default login`
2. **Permission Denied** - Verify your account has required IAM roles
3. **Backend Not Found** - Check `BACKEND_SERVICE` and `GCP_PROJECT_ID` values are exact
4. **Invalid JSON** - Validate `CAPACITY_UPDATES` JSON format with a JSON validator

### Getting Help
- **For immediate help**: Run `python capacity_scaler.py --help`
- **For pipeline issues**: Check GitLab job logs for detailed error messages
- **For authentication**: Use `gcloud auth list` to verify your credentials

## 🎯 Quick Reference

### Required Variables
| Variable | Example | Purpose |
|----------|---------|---------|
| `GCP_PROJECT_ID` | `my-gcp-project` | Your GCP project |
| `BACKEND_SERVICE` | `my-backend-service` | Target backend service |
| `CAPACITY_UPDATES` | `{"neg-a": 0.5}` | Desired capacity changes |

### Available Pipeline Jobs
> **Note**: Some jobs may be implementation-specific. Check your `.gitlab-ci.yml` for available jobs.

| Job | Purpose | Status |
|-----|---------|---------|
| `verify-capacity-changes` | Preview changes | ✅ Available |
| `apply-capacity-changes` | Apply changes | ✅ Available |
| `validate-operation` | Validate setup | ✅ Available |
| `emergency-scale-down` | Emergency scale to 0.1 | 🚧 May need implementation |
| `peak-load-scale` | Scale to maximum | 🚧 May need implementation |
| `list-backends` | Show current state | 🚧 May need implementation |
