# GitLab Pipeline Quick Start

## 🚀 Quick Steps to Run Pipeline

### 1. Get GCP Token
```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
gcloud auth print-access-token
```

### 2. GitLab Pipeline Variables
When running pipeline, set these variables:

| Variable | Example Value |
|----------|---------------|
| `GCP_PROJECT_ID` | `my-production-project` |
| `BACKEND_SERVICE` | `my-app-backend-service` |
| `GCP_ACCESS_TOKEN` | `ya29.a0AfH6SMC...` (from step 1) |
| `OPERATION_TYPE` | `capacity-change` |
| `CAPACITY_UPDATES` | `{"neg-a": 0.8, "neg-b": 0.6}` |

### 3. Execute Pipeline Jobs
1. **Run Pipeline** with variables above
2. **Trigger** `verify-capacity-changes` (preview changes)
3. **Review** output carefully
4. **Trigger** `apply-capacity-changes` (apply changes)

## 📋 Common CAPACITY_UPDATES Examples

### Scale Down for Maintenance
```json
{"neg-west": 0.2, "neg-east": 0.2, "neg-central": 0.2}
```

### Normal Traffic Distribution
```json
{"neg-west": 0.7, "neg-east": 0.8, "neg-central": 0.6}
```

### Prepare for High Traffic
```json
{"neg-west": 1.0, "neg-east": 1.0, "neg-central": 1.0}
```

### Gradual Rollout
```json
{"neg-west": 0.3, "neg-east": 0.5, "neg-central": 0.4}
```

## ⚠️ Important Notes

- **Access tokens expire in 1 hour** - get fresh token for each run
- **Always run verify stage first** - preview changes before applying
- **Copy exact backend names** - they are case-sensitive
- **Use valid JSON format** - validate with tools like jq

## 🆘 Troubleshooting

| Error | Solution |
|-------|----------|
| Token expired | Run `gcloud auth print-access-token` again |
| Permission denied | Check IAM roles and project access |
| Backend not found | Verify backend service name is exact |
| Invalid JSON | Test with `echo '{"key": 0.5}' \| jq .` |

## 📚 Full Documentation

For detailed instructions, see [PIPELINE_EXECUTION.md](PIPELINE_EXECUTION.md)
