# GCP Load Balancer Backend Utilization Manager

This Ansible solution provides direct execution to manage GCP Load Balancer backend utilization for zonal NEGs (Network Endpoint Groups).

## Features

- Update utilization for selected backends only
- Direct Ansible playbook execution
- Support for single or multiple backend updates
- Dry-run capability to preview changes
- Cross-platform support (Windows, Linux, Mac)
- Validation and confirmation prompts
- Comprehensive error handling
- Pure Ansible implementation

## Prerequisites

1. **Ansible with GCP support**
2. **GCP Authentication** (Service Account or ADC)
3. **Required permissions** on GCP Load Balancer resources

## Installation

### 1. Install Ansible and GCP Collections

```bash
# Install Ansible with GCP support
pip install ansible[gcp]

# Install required collections
ansible-galaxy collection install -r requirements.yml
```

### 2. Set up GCP Authentication

Choose one of the following methods:

#### Option A: Service Account Key File
```bash
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account-key.json"
```

#### Option B: Application Default Credentials
```bash
gcloud auth application-default login
```

## Usage

### Direct Ansible Execution

Execute the playbook directly with command-line parameters:

#### Single Backend Update
```bash
ansible-playbook playbook.yml \
  -e gcp_project_id="my-project" \
  -e backend_service="my-lb" \
  -e 'backends={"neg-1":{"neg_name":"neg-1","zone":"us-west1-a","max_utilization":0.8}}'
```

#### Multiple Backends Update
```bash
ansible-playbook playbook.yml \
  -e gcp_project_id="my-project" \
  -e backend_service="my-lb" \
  -e 'backends={"neg-1":{"neg_name":"neg-1","zone":"us-west1-a","max_utilization":0.8},"neg-2":{"neg_name":"neg-2","zone":"us-west1-b","max_utilization":0.9,"capacity_scaler":0.8}}'
```

#### Additional Options
```bash
# Preview changes without applying
ansible-playbook playbook.yml --check \
  -e gcp_project_id="my-project" \
  -e backend_service="my-lb" \
  -e 'backends={"neg-1":{"neg_name":"neg-1","zone":"us-west1-a","max_utilization":0.8}}'

# Verbose output for debugging
ansible-playbook playbook.yml -vvv \
  -e gcp_project_id="my-project" \
  -e backend_service="my-lb" \
  -e 'backends={"neg-1":{"neg_name":"neg-1","zone":"us-west1-a","max_utilization":0.8}}'

# Use specific service account file
ansible-playbook playbook.yml \
  -e gcp_project_id="my-project" \
  -e backend_service="my-lb" \
  -e 'backends={"neg-1":{"neg_name":"neg-1","zone":"us-west1-a","max_utilization":0.8}}' \
  -e service_account_file="/path/to/key.json"

# Auto-confirm without prompts
ansible-playbook playbook.yml \
  -e gcp_project_id="my-project" \
  -e backend_service="my-lb" \
  -e 'backends={"neg-1":{"neg_name":"neg-1","zone":"us-west1-a","max_utilization":0.8}}' \
  -e auto_confirm=true
```

## Configuration

### Backend Configuration Format

For multiple backends, use this JSON structure:

```json
{
  "neg-1": {
    "neg_name": "neg-1",
    "zone": "us-west1-a",
    "max_utilization": 0.8,
    "capacity_scaler": 1.0
  },
  "neg-2": {
    "neg_name": "neg-2", 
    "zone": "us-west1-b",
    "max_utilization": 0.9,
    "capacity_scaler": 0.8
  }
}
```

**Required fields:**
- `neg_name`: Name of the Network Endpoint Group
- `zone`: GCP zone where the NEG is located
- `max_utilization`: Target utilization (0.0-1.0)

**Optional fields:**
- `capacity_scaler`: Capacity scaling factor (0.0-1.0, default: 1.0)

### Environment Variables

Set these environment variables for easier usage:

```bash
export GCP_PROJECT_ID="your-project-id"
export GCP_BACKEND_SERVICE="your-backend-service"
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account.json"
```

## Examples

### Example 1: Update Single Backend

```bash
# Increase utilization of neg-web-1 to 85%
ansible-playbook playbook.yml \
  -e gcp_project_id="my-web-project" \
  -e backend_service="web-lb-backend" \
  -e 'backends={"neg-web-1":{"neg_name":"neg-web-1","zone":"us-central1-a","max_utilization":0.85}}'
```

### Example 2: Update Multiple Backends

```bash
# Update multiple backends with different settings
ansible-playbook playbook.yml \
  -e gcp_project_id="my-web-project" \
  -e backend_service="web-lb-backend" \
  -e 'backends={"neg-web-1":{"neg_name":"neg-web-1","zone":"us-central1-a","max_utilization":0.85},"neg-web-2":{"neg_name":"neg-web-2","zone":"us-central1-b","max_utilization":0.90,"capacity_scaler":0.8},"neg-api-1":{"neg_name":"neg-api-1","zone":"us-west1-a","max_utilization":0.75}}'
```

### Example 3: Dry Run to Preview Changes

```bash
# Preview what would change without applying
ansible-playbook playbook.yml --check \
  -e gcp_project_id="my-web-project" \
  -e backend_service="web-lb-backend" \
  -e 'backends={"neg-web-1":{"neg_name":"neg-web-1","zone":"us-central1-a","max_utilization":0.85}}'
```

## Troubleshooting

### Common Issues

1. **Authentication Errors**
   ```
   Solution: Verify GCP credentials and permissions
   - Check service account key file path
   - Ensure proper IAM roles (Compute Load Balancer Admin)
   ```

2. **NEG Not Found**
   ```
   Solution: Verify NEG name and zone
   - Check if NEG exists in specified zone
   - Ensure correct spelling and case
   ```

3. **Backend Service Not Found**
   ```
   Solution: Verify backend service name and project
   - Check if backend service exists in project
   - Ensure correct project ID
   ```

4. **Permission Denied**
   ```
   Solution: Check IAM permissions
   Required roles:
   - roles/compute.loadBalancerAdmin
   - roles/compute.networkAdmin (if modifying NEGs)
   ```

### Debugging

Enable verbose output for detailed information:

```bash
# Linux/Mac
./run.sh --project "my-project" --backend-service "my-lb" \
  --neg-name "neg-1" --zone "us-west1-a" --utilization 0.8 --verbose
```

```powershell
# PowerShell
.\run.ps1 -Project "my-project" -BackendService "my-lb" `
  -NegName "neg-1" -Zone "us-west1-a" -Utilization 0.8 -Verbose
```

Or run Ansible directly with debug:

```bash
ansible-playbook playbook.yml -vvv \
  -e gcp_project_id="my-project" \
  -e backend_service="my-lb" \
  -e 'backends={"neg1":{"neg_name":"neg1","zone":"us-west1-a","max_utilization":0.8}}'
```

## Security Considerations

1. **Service Account Keys**: Store securely and limit permissions
2. **IAM Roles**: Follow principle of least privilege
3. **Network Access**: Ensure proper VPC and firewall configurations
4. **Audit Logging**: Enable GCP audit logs for change tracking

## Integration with Existing Terraform

This Ansible solution can complement your existing Terraform setup:

1. **Terraform**: Manage infrastructure (load balancers, NEGs, etc.)
2. **Ansible**: Manage operational changes (utilization updates)

You can use both tools together in your CI/CD pipeline for complete infrastructure management.

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review Ansible and GCP documentation
3. Verify IAM permissions and authentication setup
